# TensorFlow MLIR

These are the docs for: https://www.tensorflow.org/mlir
